const CONFIG = {
  refreshSeconds: 60,
  limit: 150,
  defaultBalance: 1000,
  defaultRisk: 1,
  defaultDailyLoss: 3,
  defaultMaxTrades: 5,
  defaultMaxLosses: 3,
  defaultRR: 2
};

const SYMBOLS = [
  "BTCUSDT",
  "ETHUSDT",
  "BNBUSDT",
  "SOLUSDT",
  "XRPUSDT",
  "DOGEUSDT",
  "ADAUSDT",
  "AVAXUSDT",
  "LINKUSDT",
  "TRXUSDT"
];

let scannerData = [];
let selectedMarket = null;

let paperHistory =
  JSON.parse(localStorage.getItem("bigjoePaperHistory") || "[]");

function $(id) {
  return document.getElementById(id);
}

function money(value) {
  return "$" + Number(value || 0).toFixed(2);
}

function price(value) {
  if (!Number.isFinite(value)) return "—";

  if (value >= 1000) {
    return value.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }

  if (value >= 1) {
    return value.toFixed(4);
  }

  return value.toFixed(6);
}

function getSettings() {
  return {
    balance: Math.max(1, Number($("accountBalance").value) || 1000),
    riskPercent: Math.max(0.1, Number($("riskPercent").value) || 1),
    dailyLossLimit: Math.max(0.5, Number($("dailyLossLimit").value) || 3),
    maxTrades: Math.max(1, Number($("maxTrades").value) || 5),
    maxLosses: Math.max(1, Number($("maxLosses").value) || 3),
    rewardRisk: Math.max(1, Number($("rewardRisk").value) || 2)
  };
}

function calculateRiskOnly() {
  const s = getSettings();

  const riskAmount = s.balance * s.riskPercent / 100;
  const dailyLoss = s.balance * s.dailyLossLimit / 100;

  const today = new Date().toISOString().slice(0, 10);

  const todayTrades = paperHistory.filter(
    t => t.date === today
  );

  const dailyPnL = todayTrades.reduce(
    (sum, t) => sum + Number(t.pnl || 0),
    0
  );

  const remaining = Math.max(0, dailyLoss + Math.min(0, dailyPnL));

  $("riskAmount").textContent = money(riskAmount);
  $("maxDailyLoss").textContent = money(dailyLoss);
  $("potentialReward").textContent =
    money(riskAmount * s.rewardRisk);
  $("remainingRisk").textContent = money(remaining);

  updateRiskStatus();

  if (selectedMarket) {
    updateTradePlan();
  }
}

function updateRiskStatus() {
  const s = getSettings();

  const today = new Date().toISOString().slice(0, 10);

  const todayTrades = paperHistory.filter(
    t => t.date === today
  );

  const losses = todayTrades.filter(
    t => Number(t.pnl || 0) < 0
  );

  const dailyPnL = todayTrades.reduce(
    (sum, t) => sum + Number(t.pnl || 0),
    0
  );

  const maxDailyLoss =
    s.balance * s.dailyLossLimit / 100;

  const lossAmount = Math.abs(Math.min(0, dailyPnL));

  let status = "SAFE";

  if (lossAmount >= maxDailyLoss) {
    status = "DAILY LIMIT";
  } else if (getConsecutiveLosses(todayTrades) >= s.maxLosses) {
    status = "COOLDOWN";
  } else if (todayTrades.length >= s.maxTrades) {
    status = "MAX TRADES";
  }

  const box = $("riskStatus");

  box.textContent = status;

  box.className = "status " +
    (status === "SAFE"
      ? "safe"
      : status === "COOLDOWN"
        ? "cooldown"
        : "blocked");
}

function getConsecutiveLosses(trades) {
  let count = 0;

  for (let i = trades.length - 1; i >= 0; i--) {
    if (Number(trades[i].pnl || 0) < 0) {
      count++;
    } else {
      break;
    }
  }

  return count;
}

function riskPermission() {
  const s = getSettings();

  const today = new Date().toISOString().slice(0, 10);

  const trades = paperHistory.filter(
    t => t.date === today
  );

  const pnl = trades.reduce(
    (sum, t) => sum + Number(t.pnl || 0),
    0
  );

  const maxLoss =
    s.balance * s.dailyLossLimit / 100;

  if (Math.abs(Math.min(0, pnl)) >= maxLoss) {
    return {
      allowed: false,
      reason: "Daily loss limit reached."
    };
  }

  if (trades.length >= s.maxTrades) {
    return {
      allowed: false,
      reason: "Maximum daily trades reached."
    };
  }

  if (getConsecutiveLosses(trades) >= s.maxLosses) {
    return {
      allowed: false,
      reason: "Consecutive-loss cooldown active."
    };
  }

  return {
    allowed: true,
    reason: "Risk controls passed."
  };
}

async function fetchCandles(symbol) {

  const url =
    "https://data-api.binance.vision/api/v3/klines" +
    `?symbol=${symbol}&interval=15m&limit=${CONFIG.limit}`;

  const response = await fetch(url);

  if (!response.ok) {
    throw new Error("Market data error");
  }

  const data = await response.json();

  return data.map(c => ({
    time: Number(c[0]),
    open: Number(c[1]),
    high: Number(c[2]),
    low: Number(c[3]),
    close: Number(c[4]),
    volume: Number(c[5])
  }));
}

function ema(values, period) {

  if (values.length < period) return [];

  const multiplier = 2 / (period + 1);

  let result = [];
  let previous =
    values.slice(0, period)
      .reduce((a, b) => a + b, 0) / period;

  result.push(previous);

  for (let i = period; i < values.length; i++) {

    previous =
      (values[i] - previous) *
      multiplier +
      previous;

    result.push(previous);
  }

  return result;
}

function calculateRSI(closes, period = 14) {

  if (closes.length <= period) return 50;

  let gains = 0;
  let losses = 0;

  for (let i = 1; i <= period; i++) {

    const change = closes[i] - closes[i - 1];

    if (change >= 0) {
      gains += change;
    } else {
      losses += Math.abs(change);
    }
  }

  let avgGain = gains / period;
  let avgLoss = losses / period;

  for (let i = period + 1; i < closes.length; i++) {

    const change = closes[i] - closes[i - 1];

    const gain = Math.max(change, 0);
    const loss = Math.max(-change, 0);

    avgGain =
      (avgGain * (period - 1) + gain) / period;

    avgLoss =
      (avgLoss * (period - 1) + loss) / period;
  }

  if (avgLoss === 0) return 100;

  const rs = avgGain / avgLoss;

  return 100 - (100 / (1 + rs));
}

function analyze(symbol, candles) {

  const closes = candles.map(c => c.close);
  const volumes = candles.map(c => c.volume);

  const fast = ema(closes, 20);
  const slow = ema(closes, 50);

  const lastPrice = closes[closes.length - 1];

  const ema20 = fast[fast.length - 1];
  const ema50 = slow[slow.length - 1];

  const rsi = calculateRSI(closes);

  let bullish = 0;
  let bearish = 0;

  let trendScore = 0;
  let structureScore = 0;
  let momentumScore = 0;
  let volumeScore = 0;

  if (ema20 > ema50) {
    bullish += 25;
    trendScore = 25;
  } else {
    bearish += 25;
    trendScore = 25;
  }

  const recent = candles.slice(-25);

  const recentHigh =
    Math.max(...recent.map(c => c.high));

  const recentLow =
    Math.min(...recent.map(c => c.low));

  if (lastPrice > recentHigh * 0.995) {
    bullish += 20;
    structureScore = 20;
  } else if (lastPrice < recentLow * 1.005) {
    bearish += 20;
    structureScore = 20;
  } else {
    structureScore = 10;
  }

  if (rsi >= 55 && rsi <= 72) {
    bullish += 15;
    momentumScore = 15;
  } else if (rsi <= 45 && rsi >= 28) {
    bearish += 15;
    momentumScore = 15;
  } else {
    momentumScore = 5;
  }

  const averageVolume =
    volumes.slice(-20)
      .reduce((a, b) => a + b, 0) / 20;

  const lastVolume =
    volumes[volumes.length - 1];

  if (lastVolume > averageVolume * 1.2) {

    volumeScore = 10;

    if (bullish > bearish) {
      bullish += 10;
    } else {
      bearish += 10;
    }

  } else {
    volumeScore = 5;
  }

  const srScore = 10;

  let direction = "WAIT";
  let score = Math.max(bullish, bearish);

  if (bullish > bearish && bullish >= 60) {
    direction = "LONG";
  } else if (bearish > bullish && bearish >= 60) {
    direction = "SHORT";
  } else {
    direction = "WAIT";
  }

  let quality = "C";

  if (score >= 80) {
    quality = "A";
  } else if (score >= 70) {
    quality = "B";
  }

  const regime =
    ema20 > ema50
      ? "BULLISH"
      : "BEARISH";

  return {
    symbol,
    price: lastPrice,
    direction,
    score,
    quality,
    regime,
    rsi,
    trendScore,
    structureScore,
    momentumScore,
    volumeScore,
    srScore,
    ema20,
    ema50,
    reason:
      direction === "LONG"
        ? "Trend and momentum favour a bullish setup."
        : direction === "SHORT"
          ? "Trend and momentum favour a bearish setup."
          : "Market conditions are not strong enough for a qualified setup."
  };
}

async function scanMarkets() {

  $("scanStatus").textContent =
    "Scanning BIGJOE AI markets...";

  $("scannerResults").innerHTML = "";

  const results = [];

  for (let i = 0; i < SYMBOLS.length; i += 3) {

    const batch = SYMBOLS.slice(i, i + 3);

    const batchResults =
      await Promise.all(
        batch.map(async symbol => {

          try {

            const candles =
              await fetchCandles(symbol);

            return analyze(symbol, candles);

          } catch (error) {

            return {
              symbol,
              error: true
            };

          }

        })
      );

    results.push(...batchResults);

    $("scanStatus").textContent =
      `Scanning ${Math.min(i + 3, SYMBOLS.length)}/${SYMBOLS.length} markets...`;
  }

  scannerData = results
    .filter(r => !r.error)
    .sort((a, b) => b.score - a.score);

  renderScanner();

  const best =
    scannerData.find(x => x.direction !== "WAIT")
    || scannerData[0];

  if (best) {
    selectMarket(best.symbol);
  }

  $("scanStatus").textContent =
    `Scan complete • ${scannerData.length} markets analysed • Auto-refresh ${CONFIG.refreshSeconds}s`;
}

function renderScanner() {

  const tbody = $("scannerResults");

  tbody.innerHTML = "";

  scannerData.forEach(item => {

    const row = document.createElement("tr");

    row.innerHTML = `
      <td><strong>${item.symbol}</strong></td>
      <td>${price(item.price)}</td>
      <td>${item.direction}</td>
      <td>${item.score}/100</td>
      <td>${item.quality}</td>
    `;

    row.addEventListener(
      "click",
      () => selectMarket(item.symbol)
    );

    tbody.appendChild(row);
  });
}

function selectMarket(symbol) {

  const market =
    scannerData.find(x => x.symbol === symbol);

  if (!market) return;

  selectedMarket = market;

  $("marketSymbol").textContent = market.symbol;
  $("marketPrice").textContent = price(market.price);
  $("score").textContent = market.score + "/100";
  $("marketRegime").textContent = market.regime;

  $("signalDirection").textContent =
    market.direction;

  $("signalQuality").textContent =
    market.quality;

  $("confidence").textContent =
    market.score + "%";

  $("signalReason").textContent =
    market.reason;

  $("bestSymbol").textContent =
    market.symbol;

  $("bestDirection").textContent =
    market.direction;

  $("bestScore").textContent =
    market.score + "/100";

  $("bestReason").textContent =
    market.reason;

  $("trendScore").textContent =
    market.trendScore + "/25";

  $("structureScore").textContent =
    market.structureScore + "/20";

  $("momentumScore").textContent =
    market.momentumScore + "/15";

  $("volumeScore").textContent =
    market.volumeScore + "/10";

  $("srScore").textContent =
    market.srScore + "/10";

  $("trendExplanation").textContent =
    market.ema20 > market.ema50
      ? "EMA20 is above EMA50, giving a bullish trend bias."
      : "EMA20 is below EMA50, giving a bearish trend bias.";

  $("structureExplanation").textContent =
    "Recent price structure is being evaluated against the latest market range.";

  $("momentumExplanation").textContent =
    `RSI is ${market.rsi.toFixed(1)}. Momentum is treated as supporting evidence, not certainty.`;

  $("volumeExplanation").textContent =
    "Recent volume is checked against its rolling average.";

  $("srExplanation").textContent =
    "Support and resistance are currently represented by the recent trading range.";

  $("tf4h").textContent = market.regime;
  $("tf1h").textContent = market.regime;
  $("tf15m").textContent = "ACTIVE";
  $("tf5m").textContent = "CONFIRM";

  updateTradePlan();
}

function updateTradePlan() {

  if (!selectedMarket) return;

  const s = getSettings();
  const market = selectedMarket;

  const entry = market.price;

  let stop;
  let target;

  const stopDistance =
    entry * 0.005;

  if (market.direction === "LONG") {

    stop = entry - stopDistance;

    target =
      entry +
      stopDistance * s.rewardRisk;

  } else if (market.direction === "SHORT") {

    stop = entry + stopDistance;

    target =
      entry -
      stopDistance * s.rewardRisk;

  } else {

    $("direction").textContent = "WAIT";
    $("entry").textContent = "—";
    $("stopLoss").textContent = "—";
    $("takeProfit").textContent = "—";
    $("riskReward").textContent = "—";
    $("positionSize").textContent = "—";
    $("notionalValue").textContent = "—";
    $("tradeMaxLoss").textContent = "—";

    $("tradePermission").textContent =
      "NO QUALIFIED SETUP";

    $("tradePermission").className =
      "permission blocked";

    $("paperTradeButton").disabled = true;

    return;
  }

  const riskAmount =
    s.balance * s.riskPercent / 100;

  const distance =
    Math.abs(entry - stop);

  const quantity =
    distance > 0
      ? riskAmount / distance
      : 0;

  const notional =
    quantity * entry;

  $("direction").textContent =
    market.direction;

  $("entry").textContent =
    price(entry);

  $("stopLoss").textContent =
    price(stop);

  $("takeProfit").textContent =
    price(target);

  $("riskReward").textContent =
    "1 : " + s.rewardRisk;

  $("positionSize").textContent =
    quantity.toFixed(6);

  $("notionalValue").textContent =
    money(notional);

  $("tradeMaxLoss").textContent =
    money(riskAmount);

  const permission =
    riskPermission();

  if (permission.allowed) {

    $("tradePermission").textContent =
      "PAPER TRADE ALLOWED • " + permission.reason;

    $("tradePermission").className =
      "permission allowed";

    $("paperTradeButton").disabled = false;

  } else {

    $("tradePermission").textContent =
      "TRADE BLOCKED • " + permission.reason;

    $("tradePermission").className =
      "permission blocked";

    $("paperTradeButton").disabled = true;
  }
}

function recordPaperTrade() {

  if (!selectedMarket) return;

  const permission =
    riskPermission();

  if (!permission.allowed) {
    alert(permission.reason);
    return;
  }

  const s = getSettings();

  const entry =
    selectedMarket.price;

  const distance =
    entry * 0.005;

  const stop =
    selectedMarket.direction === "LONG"
      ? entry - distance
      : entry + distance;

  const target =
    selectedMarket.direction === "LONG"
      ? entry + distance * s.rewardRisk
      : entry - distance * s.rewardRisk;

  const riskAmount =
    s.balance * s.riskPercent / 100;

  const quantity =
    riskAmount / distance;

  const trade = {

    id: Date.now(),

    date:
      new Date().toISOString().slice(0, 10),

    time:
      new Date().toLocaleTimeString(),

    symbol:
      selectedMarket.symbol,

    direction:
      selectedMarket.direction,

    entry,
    stop,
    target,

    quantity,

    risk:
      riskAmount,

    score:
      selectedMarket.score,

    pnl: 0,

    status: "OPEN / PAPER"
  };

  paperHistory.unshift(trade);

  localStorage.setItem(
    "bigjoePaperHistory",
    JSON.stringify(paperHistory)
  );

  renderHistory();
  updateRiskStatus();
  updateTradePlan();

  alert(
    "BIGJOE AI paper trade recorded.\n\n" +
    `${trade.symbol} ${trade.direction}\n` +
    `Risk: ${money(trade.risk)}\n` +
    `Position: ${trade.quantity.toFixed(6)}`
  );
}

function renderHistory() {

  const box = $("history");

  if (!paperHistory.length) {

    box.textContent =
      "No paper trades recorded yet.";

    return;
  }

  box.innerHTML =
    paperHistory.slice(0, 20).map(t => `
      <div class="history-item">
        <strong>${t.symbol}</strong>
        • ${t.direction}
        • Score ${t.score}/100
        • Risk ${money(t.risk)}
        • ${t.status}
        <br>
        <small>
          ${t.date} ${t.time}
          • Entry ${price(t.entry)}
          • SL ${price(t.stop)}
          • TP ${price(t.target)}
        </small>
      </div>
    `).join("");
}

$("calculateRisk")
  .addEventListener("click", calculateRiskOnly);

$("scanButton")
  .addEventListener("click", scanMarkets);

$("paperTradeButton")
  .addEventListener(
    "click",
    recordPaperTrade
  );

[
  "accountBalance",
  "riskPercent",
  "dailyLossLimit",
  "maxTrades",
  "maxLosses",
  "rewardRisk"
].forEach(id => {

  $(id).addEventListener(
    "input",
    calculateRiskOnly
  );

});

renderHistory();
calculateRiskOnly();
scanMarkets();

setInterval(
  scanMarkets,
  CONFIG.refreshSeconds * 1000
);