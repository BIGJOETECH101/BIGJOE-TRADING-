(() => {
  const $ = id => document.getElementById(id);
  const money = n => '$' + Number(n || 0).toFixed(2);
  let adminToken = sessionStorage.getItem('BIGJOE_ADMIN_TOKEN') || '';
  let tokenPrompted = false;
  function getAdminToken() {
    if (!adminToken && !tokenPrompted) {
      tokenPrompted = true;
      adminToken = window.prompt('Enter the BIGJOE AI admin token configured privately on the backend:') || '';
      if (adminToken) sessionStorage.setItem('BIGJOE_ADMIN_TOKEN', adminToken);
    }
    return adminToken;
  }
  async function api(path, method='GET', body) {
    const token = getAdminToken();
    if (!token) throw new Error('Admin token is required to access the protected trading controls.');
    const r = await fetch('/api' + path, {method, headers:{'Content-Type':'application/json','X-Admin-Token':token}, body:body?JSON.stringify(body):undefined});
    const data = await r.json().catch(()=>({error:'Invalid server response'}));
    if(!r.ok || data.ok===false) { if(r.status===401){adminToken='';sessionStorage.removeItem('BIGJOE_ADMIN_TOKEN');tokenPrompted=false;} throw new Error(data.error || `HTTP ${r.status}`); }
    return data;
  }
  function message(text, bad=false){$('botMessage').textContent=text;$('botMessage').style.color=bad?'#b42318':'';}
  function render(s){
    $('liveBotState').textContent=s.emergencyStop?'EMERGENCY STOP':s.running?'RUNNING':'STOPPED';
    $('liveBotState').className='status '+(s.running?'safe':'blocked');
    $('botMode').textContent=s.mode||'TESTNET';
    $('botUsdt').textContent=s.usdt?money(s.usdt.free):'Not connected';
    $('botPositions').textContent=String((s.positions||[]).length);
    $('botPnl').textContent=money(s.realizedPnl);
    if(s.settings){$('botMaxQuote').value=s.settings.maxQuote;$('botRiskPct').value=s.settings.riskPct;$('botDailyLossPct').value=s.settings.dailyLossPct;$('botMaxTrades').value=s.settings.maxTradesPerDay;}
    const logs=s.logs||[];
    $('botLogs').innerHTML=logs.length?logs.map(l=>`<tr><td>${new Date(l.time).toLocaleTimeString()}</td><td>${escapeHtml(l.event)}</td><td>${escapeHtml(l.details)}</td></tr>`).join(''):'<tr><td colspan="3">No events recorded yet.</td></tr>';
    if(s.lastError)message('Engine error: '+s.lastError,true);
    else if(!s.configured)message('Backend is running, but Binance Spot Testnet API credentials are not configured.',true);
    else if(!s.automationAllowed)message('Credentials detected. Set ALLOW_AUTOMATION=true on the server to unlock testnet start.',true);
    else message(s.running?'Robot is active on TESTNET. Watch logs and positions.':'Backend connected. Robot is stopped.');
  }
  function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  async function refresh(){try{render(await api('/status'));}catch(e){message('Backend connection failed: '+e.message+' — deploy/run server.js, not just static files.',true);}}
  $('botSaveSettings').addEventListener('click',async()=>{try{const s=await api('/settings','POST',{maxQuote:Number($('botMaxQuote').value),riskPct:Number($('botRiskPct').value),dailyLossPct:Number($('botDailyLossPct').value),maxTradesPerDay:Number($('botMaxTrades').value)});message('Bot limits saved.');render(await api('/status'));}catch(e){message(e.message,true);}});
  $('botStart').addEventListener('click',async()=>{if(!confirm('Start automatic trading on BINANCE SPOT TESTNET only? No real funds should be used.'))return;try{const r=await api('/start','POST',{});message(r.message);await refresh();}catch(e){message(e.message,true);}});
  $('botStop').addEventListener('click',async()=>{try{const r=await api('/stop','POST',{});message(r.message);await refresh();}catch(e){message(e.message,true);}});
  $('botEmergency').addEventListener('click',async()=>{if(!confirm('Emergency stop disables the robot but does NOT sell or close open positions. Continue?'))return;try{const r=await api('/emergency-stop','POST',{});message(r.message,true);await refresh();}catch(e){message(e.message,true);}});
  refresh();setInterval(refresh,10000);
})();
