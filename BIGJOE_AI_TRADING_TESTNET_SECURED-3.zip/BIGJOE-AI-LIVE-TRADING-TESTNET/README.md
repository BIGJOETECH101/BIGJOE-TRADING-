# BIGJOE AI LIVE TRADING ROBOT — Binance Spot Testnet

This bundle preserves the existing BIGJOE AI dashboard (`index.html`, `style.css`, `app.js`) and adds a Node.js backend for Binance Spot Testnet. It is a development/testnet implementation, not a guarantee of profitable or flawless trading. It deliberately refuses to start unless testnet mode, API credentials, an admin token, and an explicit server-side automation flag are configured. The health check is public; all other API routes require the private admin token.

## Safety design
- `BINANCE_TESTNET=true` by default; server blocks trading if false. Do not change this for live trading.
- `ALLOW_AUTOMATION=false` by default; set true only after the testnet API key is installed and you are ready to test.
- `ADMIN_TOKEN` protects account status, settings, logs, and all trading controls. Generate a long random token, keep it private, and enter it in the dashboard prompt. It is kept in session storage only.
- Use Binance Spot **Test Network** keys only, not your normal Binance keys. Disable withdrawals; grant only the permissions needed for Spot trading. Never put secrets in browser JavaScript, HTML, a public repository, or this chat.
- One position per symbol, max 3 open positions, maximum quote per order default 25 USDT, risk target 1%, daily loss threshold 3%, 5 entries/day, three-loss pause, 30-minute per-symbol cooldown. UI/server validate conservative bounds.
- BUY entries only; Spot does not short. Exit logic monitors stop loss/take profit on the server and sends market SELL orders. Therefore exits are not exchange-hosted protective orders: if the server or internet goes offline, automated exits pause. Testnet only until separately reviewed.
- Every market order is followed by a query of its order ID and must be FILLED/PARTIALLY_FILLED before state is updated. Logs and positions are stored in `data/state.json`. Back up persistent state and monitor the server.
- Daily counters use UTC. P/L is estimated from fill average prices and does not fully account for commissions; it is not an accounting statement.

## Run locally (computer or Android terminal)
Requires Node.js 20+.
1. Extract this ZIP to a project folder.
2. Copy `.env.example` to `.env`.
3. Create a Binance Spot Testnet account at `https://testnet.binance.vision/` and generate Testnet API credentials. Do not use real exchange keys.
4. Put the Testnet key and secret in `.env`; generate a long random `ADMIN_TOKEN`; keep `ALLOW_AUTOMATION=false` until the deployment checks pass.
5. Run `npm install` then `npm start`.
6. Open `http://localhost:3000`. Check `/api/health`, verify TESTNET and balances, then press **START TESTNET ROBOT**.

## Deploy to Render
1. Upload/extract this project into a private GitHub repository. Never commit `.env` or API keys.
2. Create a Render Web Service from that repository. Runtime Node; build `npm install`; start `npm start`.
3. Add environment variables `BINANCE_TESTNET=true`, `ALLOW_AUTOMATION=false`, `ADMIN_TOKEN` (long random secret), `BINANCE_API_KEY`, `BINANCE_API_SECRET`, and `STATE_FILE=/opt/render/project/src/data/state.json`. Add a persistent disk mounted at `/opt/render/project/src/data`.
4. Deploy and open `/api/health`; confirm `BINANCE_SPOT_TESTNET`. Verify all other API routes reject requests without `X-Admin-Token`. With `ALLOW_AUTOMATION=false`, use the dashboard to confirm Testnet credentials and balance. Only after that verification, set `ALLOW_AUTOMATION=true` and use the dashboard Start button to begin Testnet trading.
5. Render free instances can sleep and ephemeral disks lose state. A persistent disk typically requires a paid service. Do not use an unreliable/sleeping host for unattended trading.

## API routes
- `GET /api/health` — public health and mode (no secret data)
- All other routes require the `X-Admin-Token` request header matching the server `ADMIN_TOKEN`.
- `GET /api/status` — testnet connectivity, balances, positions and logs
- `POST /api/settings` — bounded risk settings
- `POST /api/start` — starts engine after safety checks
- `POST /api/stop` — pauses new entries while continuing to monitor existing positions for exits
- `POST /api/emergency-stop` — disables the engine immediately; does not liquidate open positions and stops automated exit monitoring
- `POST /api/scan` — signals for configured markets

## Before any real-money use
This bundle is intentionally not approved for live trading. It lacks exchange-hosted stop orders, full commission/fee accounting, robust partial-fill recovery, multi-process locking, and a complete independent audit. Do not point it at the live Binance API. Test through market regimes and inspect order histories before considering any further development.
